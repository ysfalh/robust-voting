# Robust Sparse Voting

### Important: if you would like to download the full repository, download the file "robust-voting.zip".

Use the following command line to run the experiments:

```bash
python3 main.py
```

The parameters of the experiments can be chosen inside the file `main.py`. 
Otherwise, the default parameters will be used.
